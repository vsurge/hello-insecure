# hello-insecure
An example of an insecure repository for testing
